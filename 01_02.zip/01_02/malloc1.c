#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void main() {
	char* s = (char*)malloc(sizeof(char) * 10);

	char param[20] = { "cos pro" };
	char* s = (char*)malloc(sizeof(char) * 10);

	int* counter = (int*)malloc(sizeof(int) * 10);
}